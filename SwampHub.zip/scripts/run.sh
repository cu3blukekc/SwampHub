#!/bin/bash
cd /vagrant
docker-compose up -d